var config = {};

config.PORT = 3000;
config.REFRESH_TAP_DELAY = 120000;

module.exports = config;
